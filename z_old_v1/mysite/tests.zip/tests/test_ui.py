import pytest

from mypkg.ui import *